RegisterNetEvent('c-motor')
AddEventHandler('c-motor', function()
    local playerPed = PlayerPedId()
    local vehicleHash = GetHashKey("sanchez")

    RequestModel(vehicleHash)
    while not HasModelLoaded(vehicleHash) do
        Wait(500)
    end

    local playerCoords = GetEntityCoords(playerPed)
    local heading = GetEntityHeading(playerPed)
    local vehicle = CreateVehicle(vehicleHash, playerCoords.x + 2, playerCoords.y, playerCoords.z, heading, true, false)

    TaskWarpPedIntoVehicle(playerPed, vehicle, -1)
end)