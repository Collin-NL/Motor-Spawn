local GebruikteMotoren= {}

RegisterCommand('motor', function(source, args, rawCommand)
    local playerId = source
    local playerIdentifier = GetPlayerIdentifier(playerId, 0)

    if GebruikteMotoren[playerIdentifier] then
        TriggerClientEvent('chat:addMessage', playerId, {
            color = {255, 0, 0},
            multiline = true,
            args = {"System", "Je hebt al een motor gespawned deze restart!"}
        })
        TriggerClientEvent('ox_lib:notify', source, 'Systeem', 'Je hebt al een motor gespawned. Je kunt er maar 1 spawnen per restart!', 'error')
        return
    end

    GebruikteMotoren[playerIdentifier] = true

    TriggerClientEvent('c-motor', playerId)
    TriggerClientEvent('chat:addMessage', playerId, {
        color = {0, 255, 0},
        multiline = true,
        args = {"System", "Je hebt een Sanchez motor gespawned!"}
    })
    TriggerClientEvent('ox_lib:notify', source, 'Systeem', 'Je hebt een Motor Gespawned!', 'success')
end, false)